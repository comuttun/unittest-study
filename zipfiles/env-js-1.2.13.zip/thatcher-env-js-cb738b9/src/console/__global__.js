
/**
 * @author envjs team
 */
var Console,
    console;
