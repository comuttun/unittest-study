
/**
 * @author thatcher
 */
CSSStyleDeclaration = function(){

};